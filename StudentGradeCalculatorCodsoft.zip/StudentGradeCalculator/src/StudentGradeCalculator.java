import java.util.Scanner;

public class StudentGradeCalculator {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Student Grade Calculator");
        System.out.print("Enter the total number of subjects: ");
        int numSubjects = scanner.nextInt();

        double totalMarks = 0;

        for (int i = 1; i <= numSubjects; i++) {
            System.out.print("Enter marks obtained in subject " + i + " (out of 100): ");
            double marks = scanner.nextDouble();
            totalMarks += marks;
        }

        double averagePercentage = totalMarks / (numSubjects * 100);

        System.out.println("Total Marks: " + totalMarks);
        System.out.println("Average Percentage: " + (averagePercentage * 100) + "%");

        char grade = calculateGrade(averagePercentage);
        System.out.println("Grade: " + grade);

        scanner.close();
    }

    public static char calculateGrade(double percentage) {
        if (percentage >= 0.9) {
            return 'A';
        } else if (percentage >= 0.8) {
            return 'B';
        } else if (percentage >= 0.7) {
            return 'C';
        } else if (percentage >= 0.6) {
            return 'D';
        } else {
            return 'F';
        }
    }
}
