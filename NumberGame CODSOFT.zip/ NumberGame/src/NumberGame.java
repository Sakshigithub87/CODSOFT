import java.util.Random;
import java.util.Scanner;

public class NumberGame {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Random random = new Random();
        int minRange = 1;
        int maxRange = 100;
        int numberOfRounds = 1;
        int maxAttempts = 5;
        int totalAttempts = 0;
        int totalRoundsWon = 0;

        System.out.println("Welcome to the Number Guessing Game!");
        System.out.println("You have " + maxAttempts + " attempts to guess the number between " + minRange + " and " + maxRange + ".");

        while (numberOfRounds <= 3) { // You can change the number of rounds if needed.
            int targetNumber = random.nextInt(maxRange - minRange + 1) + minRange;
            int attempts = 0;

            System.out.println("\nRound " + numberOfRounds + ":");
            while (attempts < maxAttempts) {
                System.out.print("Attempt " + (attempts + 1) + ": Enter your guess: ");
                int userGuess = scanner.nextInt();
                attempts++;

                if (userGuess == targetNumber) {
                    System.out.println("Congratulations! You guessed the number in " + attempts + " attempts.");
                    totalRoundsWon++;
                    totalAttempts += attempts;
                    break;
                } else if (userGuess < targetNumber) {
                    System.out.println("Try again. Your guess is too low.");
                } else {
                    System.out.println("Try again. Your guess is too high.");
                }

                if (attempts == maxAttempts) {
                    System.out.println("You've run out of attempts. The correct number was " + targetNumber + ".");
                    totalAttempts += attempts;
                }
            }

            numberOfRounds++;
            System.out.println("\nRounds won: " + (totalRoundsWon - 1) + " out of " + (numberOfRounds - 2));
            System.out.println("Total attempts: " + totalAttempts + " across all rounds");
            System.out.println("Would you like to play another round? (yes/no)");
            String playAgain = scanner.next().toLowerCase();

            if (!playAgain.equals("yes")) {
                break;
            }
        }

        System.out.println("\nThanks for playing!");
    }
}

